#include "structures.h"

void InitialisationPosition(SDL_Rect *Position, int x, int y, int h, int w)
{
    Position->x=x;
    Position->y=y;
    Position->h=h;
    Position->w=w;
}
